
function A=random(n)
  rand('seed',0);
  A = 2* rand(n) - 1;
